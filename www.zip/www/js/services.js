angular.module('starter.services', ['ngCordova'])

.factory('LoginService', function ($http, $q) {
    return {
        login: function(loginData) {
            return $q(function(resolve, reject) {
                var req = {
                  method: 'POST',
                  url: 'http://91.245.226.161:5000/api/v1/authenticate/',
                  // url: 'http://127.0.0.1:8000/api/v1/authenticate/',
                  headers: {
                      'Content-Type': 'application/json'
                  },
                  data: { username: loginData.login, password: loginData.password }
                }

                $http(req).then(function(data) {
                    localStorage.setItem('currentUser', JSON.stringify(data.data));
                    resolve(data.data);
                }, function(error)
                {
                    resolve(error.data);
                });
            });
        },

        logout: function() {
            window.localStorage.removeItem('currentUser');
        },
    }
})

.factory('DataService', function ($http, $q) {
    $http.defaults.headers.common.Authorization = 'Token ' + window.localStorage.getItem("token");
    return {
        update_skv_details: function(well, fluid, teh_rej_water, teh_rej_oil, teh_rej_fluid, gas) {
            return $q(function(resolve, reject) {
                var req = {
                  method: 'POST',
                  url: 'http://91.245.226.161:5000/api/v1/well_matrix/create_wellmatrix/',
                  headers: {
                      'Content-Type': 'application/json'
                  },
                  data: {well: well, fluid: fluid, teh_rej_water: teh_rej_water, teh_rej_oil: teh_rej_oil, teh_rej_fluid: teh_rej_fluid, gas: gas}
                }

                $http(req).then(function(data) {
                    resolve(data);
                }, function(error)
                {
                    resolve(error.data);
                });
            });
        },
        update_field_details: function(field, fluid, oilbrutto, oilnetto, density) {
            return $q(function(resolve, reject) {
                var req = {
                  method: 'POST',
                  url: 'http://91.245.226.161:5000/api/v1/field_balance/create_balance/',
                  headers: {
                      'Content-Type': 'application/json'
                  },
                  data: {field: field, transport_balance: fluid, transport_brutto: oilbrutto, transport_netto: oilnetto, transport_density: density}
                }

                $http(req).then(function(data) {
                    resolve(data);
                }, function(error)
                {
                    resolve(error.data);
                });
            });
        },
        getFields: function() {
            return $q(function(resolve, reject) {
                $http.get("http://91.245.226.161:5000/api/v1/fields/")
                .success(function(response) { 
                    resolve(response);
                });
            });
        },
        getWells: function(field) {
            if (field == 'Общее') {
                return $q(function(resolve, reject) {
                    $http.get("http://91.245.226.161:5000/api/v1/wells")
                    .success(function(response) { 
                        resolve(response);
                    });
                });
            } else {
                return $q(function(resolve, reject) {
                    $http.get("http://91.245.226.161:5000/api/v1/wells/get_by_field?field=" + field)
                    .success(function(response) { 
                        resolve(response);
                    });
                });
            }
                
        },
        getTotalBalance: function(month) {
            return $q(function(resolve, reject) {
                $http.get("http://91.245.226.161:5000/api/v1/field_balance/get_total?month=" + month)
                .success(function(response) { 
                    resolve(response);
                });
            });
        },
        getFieldBalance: function(month, field) {
            return $q(function(resolve, reject) {
                $http.get("http://91.245.226.161:5000/api/v1/field_balance/get_by_field?month=" + month + "&field=" + field)
                .success(function(response) { 
                    resolve(response);
                });
            });
        },
        getTotalMatrix: function() {
            return $q(function(resolve, reject) {
                $http.get("http://91.245.226.161:5000/api/v1/well_matrix/")
                .success(function(response) { 
                    resolve(response);
                });
            });
        },
        getFieldMatrix: function(field) {
            return $q(function(resolve, reject) {
                $http.get("http://91.245.226.161:5000/api/v1/well_matrix/get_by_field?field=" + field)
                .success(function(response) { 
                    resolve(response);
                });
            });
        },
        getReverseCalculation: function() {
            return $q(function(resolve, reject) {
                $http.get("http://91.245.226.161:5000/api/v1/reverse/")
                .success(function(response) { 
                    resolve(response);
                });
            });
        },
    }
});
