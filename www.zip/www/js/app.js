// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

  .run(function($ionicPlatform, $rootScope) {
    $ionicPlatform.ready(function(event, toState, toParams) {
        if (window.cordova && window.cordova.plugins.Keyboard) {
          cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
          cordova.plugins.Keyboard.disableScroll(true);
        }
        if (window.StatusBar) {
          StatusBar.styleDefault();
        }
    });
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
        var requireLogin = toState.data.requireLogin;
        if (requireLogin && !window.localStorage.getItem("currentUser")) {
            event.preventDefault();
        }
    });
  })



  .config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
      .state('login', {
        url: "/login",
        templateUrl: "templates/login.html",
        controller: 'LoginCtrl',
        data: {
            requireLogin: false
        }
      })
      .state('app', {
        url: '/app',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl',
        data: {
            requireLogin: true
        }
      })
      .state('app.balans', {
        url: '/balans',
        views: {
          'menuContent': {
            templateUrl: 'templates/balans.html',
            controller: 'BalansCtrl'
          }
        }
      })
      .state('app.report', {
        url: '/report',
        views: {
          'menuContent': {
            templateUrl: 'templates/report.html',
            controller: 'BalansCtrl'
          }
        }
      });

    $urlRouterProvider.otherwise('/login');
  });
