 angular.module('starter.controllers', ['chart.js', 'ngCordova', '720kb.datepicker'])
  

  .controller('LoginCtrl', function($scope, $state, $ionicHistory, LoginService) {
    
    $scope.show = true;
    $scope.loginData = {
        login: "",
        password: "",
    };
    $scope.message = "";
    
    if (window.localStorage.getItem("token")) {
        $ionicHistory.clearHistory();
        $ionicHistory.nextViewOptions({
            disableAnimate: true,
            disableBack: true
        });
        $state.go('app.balans');
    } else {
        $scope.show = true;
    }


    $scope.login = function(loginData) {
        var promise = LoginService.login(loginData);
        promise.then(function(data) {
            if (data.user) {
                $ionicHistory.clearHistory();
                $ionicHistory.nextViewOptions({
                    disableAnimate: true,
                    disableBack: true
                });
                window.localStorage.setItem("token", data.token);
                $state.go('app.balans');
            } else {
                $scope.error_message = data.non_field_errors[0];
            }   
        });
    }

  })
  .controller('AppCtrl', function($scope, $ionicModal, $ionicHistory, $state) {
      $scope.logout = function() {
          window.localStorage.removeItem('currentUser');
          window.localStorage.removeItem('token');
          $ionicHistory.clearHistory();
          $ionicHistory.nextViewOptions({
            disableAnimate: true,
            disableBack: true
          });
          $state.go('login');
      }
  })
  
  .controller("BalansCtrl", function($scope, DataService, $state, $ionicHistory, $ionicModal, $ionicPopup) {
    $scope.show = true;
    $scope.zoom = false;
    $scope.skvModal = '';
    $scope.field = 'Общее';
    $scope.rev_field = 'Общее';
    $scope.field_second = 'Общее';
    $scope.main_field = 'Общее';
    $scope.fields = ['Общее'];
    $scope.rev_fields = ['Общее'];
    $scope.well = 'Выбрать скважину';
    $scope.wells = ['Выбрать скважину'];
    $scope.month = new Date().getMonth();
    $scope.month_txt = $scope.month.toString();
    $scope.balance_jidkost = 'Жидкость';

    $scope.operator_first = true;
    $scope.operator_second = true;

    $scope.fluid_upd = "";
    $scope.teh_rej_water_upd = "";
    $scope.teh_rej_oil_upd = "";
    $scope.teh_rej_fluid_upd = "";
    $scope.gas_upd = "";

    $scope.field_fluid_upd = "";
    $scope.field_oilbrutto_upd = "";
    $scope.field_oilnetto_upd = "";
    $scope.field_density_upd = "";

    var balance_data = [];
    var matrix_data = [];
    var reverse_data = {};
    $scope.reverse_today_date = (new Date().toISOString()).slice(0,10);

    var promise = DataService.getFields();
    promise.then(function(data) {
        for (i in data) {
            $scope.fields.push(data[i].name);
            $scope.rev_fields.push(data[i].name);
        }
    });

    var promise = DataService.getTotalBalance($scope.month + 1);
    promise.then(function(data) {
        balance_data = data;
        run();
    });
    var promise = DataService.getTotalMatrix();
    promise.then(function(data) {
        matrix_data = data;
        run_matrix();
    });
    var promise = DataService.getReverseCalculation();
    promise.then(function(data) {
        for (var i in data) {
            var temp = [];
            if (!(data[i].timestamp in reverse_data)) {
                reverse_data[data[i].timestamp] = {};
            }
            if (!(data[i].well.field.name in reverse_data[data[i].timestamp])) {
                reverse_data[data[i].timestamp][data[i].well.field.name] = [];
            }
            temp.push(data[i].timestamp);
            temp.push(data[i].well.field.name);
            temp.push(data[i].well.name);
            temp.push(data[i].calc_time);
            temp.push(data[i].fluid);
            temp.push(data[i].teh_rej_fluid);
            temp.push(data[i].teh_rej_oil);
            temp.push(data[i].teh_rej_water);
            temp.push(data[i].density);
            temp.push(data[i].stop_time);
            var fluid_loss = data[i].fluid / data[i].calc_time * data[i].stop_time;
            var day_fluid = 24 / data[i].calc_time * data[i].fluid - fluid_loss;
            var day_oil = day_fluid * (100 - data[i].teh_rej_water) * data[i].density / 100;
            var oil_loss = fluid_loss * (100 - data[i].teh_rej_water) * data[i].density / 100;
            temp.push(day_fluid);
            temp.push(day_oil);
            temp.push(fluid_loss);
            temp.push(oil_loss);
            reverse_data[data[i].timestamp][data[i].well.field.name].push(temp);
        }
        run_reverse();
    });

    var startTime = function() {
        var today = new Date();
        var day = checkTime(today.getDate());
        var month = checkTime(today.getMonth() + 1);
        var str = day.toString() + "." + month.toString() + '.' + today.getFullYear().toString();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        h = checkTime(h);
        m = checkTime(m);
        s = checkTime(s);
        document.getElementById('clock_time').innerHTML = str + "<br>" + h + ":" + m + ":" + s;
        var t = setTimeout(startTime, 500);
    }
    var checkTime = function(i) {
        if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
        return i;
    }

    var createCharts = function() {
        Highcharts.theme = {
           colors: ['#2b908f', '#90ee7e', '#f45b5b', '#7798BF', '#aaeeee', '#ff0066',
              '#eeaaee', '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
           chart: {
              // backgroundColor: {
              //    linearGradient: { x1: 0, y1: 0, x2: 1, y2: 1 },
              //    stops: [
              //       [0, '#2a2a2b'],
              //       [1, '#3e3e40']
              //    ]
              // },
              backgroundColor: '#19191E',
              style: {
                 fontFamily: '\'Unica One\', sans-serif'
              },
              plotBorderColor: '#606063'
           },
           title: {
              style: {
                 color: '#E0E0E3',
                 textTransform: 'uppercase',
                 fontSize: '0.8vw'
              }
           },
           subtitle: {
              style: {
                 color: '#E0E0E3',
                 textTransform: 'uppercase'
              }
           },
           xAxis: {
              gridLineWidth: 0,
              gridLineColor: '#707073',
              labels: {
                 style: {
                    color: '#E0E0E3',
                    fontSize: '0.8vw'
                 }
              },
              lineColor: '#707073',
              minorGridLineColor: '#505053',
              tickColor: '#707073',
              title: {
                 style: {
                    color: '#A0A0A3'

                 }
              }
           },
           yAxis: {
              gridLineWidth: 0,
              gridLineColor: '#707073',
              labels: {
                 style: {
                    color: '#E0E0E3',
                    fontSize: '0.8vw'
                 }
              },
              lineColor: '#707073',
              minorGridLineColor: '#505053',
              tickColor: '#707073',
              tickWidth: 1,
              tickAmount: 5,
              title: {
                 style: {
                    color: '#A0A0A3'
                 }
              }
           },
           tooltip: {
              backgroundColor: 'rgba(0, 0, 0, 0.85)',
              style: {
                 color: '#F0F0F0',
                 fontSize: '0.8vw'
              },
              formatter: function(d){
                  var rV = this.x  + " <br/>";
                  
                  this.points.forEach(function(d){
                      if (!d.series.name.includes('Поддержание')) {
                          rV += '<span style="color:' + d.color + '">\u25CF</span> ' + d.series.name + ': <b> ' + d.y + '</b><br/>';
                      }
                  });     
              return rV;
            },
            shared: true
           },
           plotOptions: {
              series: {
                 dataLabels: {
                    color: '#B0B0B3'
                 },
                 marker: {
                    lineColor: '#333'
                 }
              },
              boxplot: {
                 fillColor: '#505053'
              },
              candlestick: {
                 lineColor: 'white'
              },
              errorbar: {
                 color: 'white'
              }
           },
           legend: {
              itemStyle: {
                 color: '#E0E0E3',
                 fontSize: '0.7vw'
              },
              itemHoverStyle: {
                 color: '#FFF'
              },
              itemHiddenStyle: {
                 color: '#606063'
              }
           },
           credits: {
              enabled: false
           },
           labels: {
              style: {
                 color: '#707073'
              }
           },

           drilldown: {
              activeAxisLabelStyle: {
                 color: '#F0F0F3'
              },
              activeDataLabelStyle: {
                 color: '#F0F0F3'
              }
           },

           navigation: {
              buttonOptions: {
                 symbolStroke: '#DDDDDD',
                 theme: {
                    fill: '#505053'
                 }
              }
           },

           // scroll charts
           rangeSelector: {
              buttonTheme: {
                 fill: '#505053',
                 stroke: '#000000',
                 style: {
                    color: '#CCC'
                 },
                 states: {
                    hover: {
                       fill: '#707073',
                       stroke: '#000000',
                       style: {
                          color: 'white'
                       }
                    },
                    select: {
                       fill: '#000003',
                       stroke: '#000000',
                       style: {
                          color: 'white'
                       }
                    }
                 }
              },
              inputBoxBorderColor: '#505053',
              inputStyle: {
                 backgroundColor: '#333',
                 color: 'silver'
              },
              labelStyle: {
                 color: 'silver'
              }
           },

           navigator: {
              handles: {
                 backgroundColor: '#666',
                 borderColor: '#AAA'
              },
              outlineColor: '#CCC',
              maskFill: 'rgba(255,255,255,0.1)',
              series: {
                 color: '#7798BF',
                 lineColor: '#A6C7ED'
              },
              xAxis: {
                 gridLineColor: '#505053'
              }
           },

           scrollbar: {
              barBackgroundColor: '#808083',
              barBorderColor: '#808083',
              buttonArrowColor: '#CCC',
              buttonBackgroundColor: '#606063',
              buttonBorderColor: '#606063',
              rifleColor: '#FFF',
              trackBackgroundColor: '#404043',
              trackBorderColor: '#404043'
           },

           // special colors for some of the
           legendBackgroundColor: 'rgba(0, 0, 0, 0.5)',
           background2: '#505053',
           dataLabelsColor: '#B0B0B3',
           textColor: '#C0C0C0',
           contrastTextColor: '#F0F0F3',
           maskColor: 'rgba(255,255,255,0.3)'
        };
        Highcharts.setOptions({
            lang:{
                resetZoom: 'Вернуться'
            }
        });
        Highcharts.setOptions(Highcharts.theme);  
        
        $scope.hour =  Highcharts.chart('containerHour', {
            exporting: {
                enabled: false
            },
            chart: {
                zoomType: 'x'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: [{
                categories: [],
                crosshair: true
            }],
            yAxis: [{ // Primary yAxis
                labels: {
                    format: '{value}',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                title: {
                    text: 'Добыча жидкости, м³',
                    style: {
                        color: Highcharts.getOptions().colors[1],
                        fontSize: '0.7vw'
                    }
                }
            }],
            tooltip: {
                shared: true
            },
            plotOptions: {
                series: {
                    dataLabels: {
                        enabled: true,
                        borderRadius: 5,
                        backgroundColor: 'rgba(252, 255, 197, 0.7)',
                        borderWidth: 1,
                        borderColor: '#AAA',
                        style: {
                        fontSize: '0.8vw',
                      },
                        y: 0,
                        x: -50,
                        align: 'left',
                        formatter: function() {
                            if (this.point.x == this.series.data.length - 1) {
                                return this.y;
                            } else {
                                return null;
                            }
                        },
                        crop: false,
                        overflow: false
                    }
                }
            },
             

            plotOptions: {
            spline: {
                marker: {
                    radius: 2
                    
                }
            }
        },

            series: [{
                name: 'Замерная добыча',
                type: 'spline',
                data: [],
                tooltip: {
                    valueSuffix: ' м³'
                }

            }, {
                name: 'Фактическая добыча',
                type: 'spline',
                dashStyle: 'shortdot',
                marker: {
                    enabled: false
                },
                data: [],
                tooltip: {
                    valueSuffix: ' м³'
                }

            }, {
                name: 'Добыча по плану',
                type: 'spline',
                data: [],
                tooltip: {
                    valueSuffix: ' м³'
                }

            }]
        });
        $scope.balansChart = Highcharts.chart('containerBalans', {
            exporting: {
                enabled: false
            },
            chart: {
                zoomType: 'x'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: [{
                categories: [],
                crosshair: true,
                // min: 0,
                // max: 12,
                // scrollbar: {
                //       enabled: true
                // },
            }],
            yAxis: [{ // Primary yAxis
                labels: {
                    format: '{value}',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                title: {
                    text: 'млн.тг',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                }
            }, { // Secondary yAxis
                title: {
                    text: 'Рентабельность',
                    style: {
                        color: Highcharts.getOptions().colors[2]
                    }
                },
                labels: {
                    format: '{value} %',
                    style: {
                        color: Highcharts.getOptions().colors[2]
                    }
                },
                opposite: true
            }],
            tooltip: {
                shared: true
            },
            series: [{
                name: 'Доход',
                type: 'column',
                data: [],
                tooltip: {
                    valueSuffix: ' млн.тг'
                }

            }, {
                name: 'Расход',
                type: 'column',
                data: [],
                tooltip: {
                    valueSuffix: ' млн.тг'
                }

            }, {
                name: 'Рентабельность',
                type: 'spline',
                yAxis: 1,
                data: [],
                tooltip: {
                    valueSuffix: ' %'
                }

            }]
        });

    }

    startTime();
    createCharts();

    $scope.year = '2019';
    $scope.title = "Суточный баланс жидкости";
    $scope.pretitle = "Замерная добыча vs Резервуарная добыча";

    $scope.ngdu = 'Kazahoil';
    $scope.mr = 'Obshee';

    $scope.allMatrixData1 = true;
    $scope.allMatrixData2 = true;
    $scope.allMatrixData3 = true;

    $scope.allMatrixOtkl1 = false;
    $scope.allMatrixOtkl2 = false;
    $scope.allMatrixOtkl3 = false;



    var run = function() {
        $scope.height = screen.height / 87;
        
        var get_data = function() {
            var daysInMonth = new Date(2019, $scope.month + 1, 0).getDate();
            var result = {
                transport_balance : Array(daysInMonth).fill(0),
                ansagan_balance : Array(daysInMonth).fill(0),
                transport_netto : Array(daysInMonth).fill(0),
                ansagan_netto : Array(daysInMonth).fill(0),
                agzu_fluid : Array(daysInMonth).fill(0),
                agzu_oil : Array(daysInMonth).fill(0),
                teh_rej_fluid : Array(daysInMonth).fill(0),
                teh_rej_oil : Array(daysInMonth).fill(0),
            };

            for (i in balance_data) {
                var day = (new Date(balance_data[i].timestamp)).getDate() - 1;
                result.transport_balance[day] = (balance_data[i].transport_balance);
                result.ansagan_balance[day] = (balance_data[i].ansagan_balance);
                result.transport_netto[day] = (balance_data[i].transport_netto);
                result.ansagan_netto[day] = (balance_data[i].ansagan_netto);
                result.agzu_fluid[day] = (balance_data[i].agzu_fluid);
                result.agzu_oil[day] = (balance_data[i].agzu_oil);
                result.teh_rej_fluid[day] = (balance_data[i].teh_rej_fluid);
                result.teh_rej_oil[day] = (balance_data[i].teh_rej_oil);
            }
            return result;
        }

        $scope.labels = ['1', '', '', '', '5', '', '','', '', '10', '', '', '', '', '15', '', '', '', '', '20', '','', '', '', '25', '', '', '', '', '30', ''];
        $scope.labels_matrix = ['1', '', '', '', '5', '', '','', '', '10', '', '', '', '', '15', '', '', '', '', '20', '','', '', '', '25', '', '', '', '', '30', ''];
        $scope.title = "Суточный баланс жидкости";
        $scope.selectedButton = 1;

        $scope.result = get_data();
        
        var udel_r1 = 0;
        var udel_r2 = 0;

        var udel_1 = [];

        var r1 = null;
        var r2 = null;

        var r3 = null;
        var r4 = null;

        if ($scope.balance_jidkost == 'Жидкость') {
            $scope.pretitle = "Данные по жидкости (Автомобильные весы и Ансаган)";
            r1 = $scope.result.transport_balance;
            r2 = $scope.result.ansagan_balance;
            r3 = $scope.result.agzu_fluid;
            r4 = $scope.result.teh_rej_fluid;
        } else {
            $scope.pretitle = "Данные по нефти (Автомобильные весы и Ансаган)";
            r1 = $scope.result.transport_netto;
            r2 = $scope.result.ansagan_netto;
            r3 = $scope.result.agzu_oil;
            r4 = $scope.result.teh_rej_oil;
        }
        for (i in r1) {
            udel_r1 += r1[i];
            udel_r2 += r2[i];
            if (udel_r2 == 0) {
                udel_1.push(null);
            } else {
                udel_1.push(parseFloat(((1 - (udel_r1/udel_r2)) * 100).toFixed(2)));    
            }
        }

        udel_r1 = 0;
        udel_r2 = 0;
        udel_jidk = 0;


        // for (var i = 0; i <= $scope.nak_day; i++) {
        //     udel_r1 += $scope.result.r1[i];
        //     udel_r2 += $scope.result.r2[i];
        //     udel_jidk += $scope.result.teh_jidk[i];
        // }

        // $scope.otkl_po_jidk = udel_r1 - udel_r2;
        // $scope.otkl_pr_jidk = ($scope.otkl_po_jidk / udel_r1) * 100;

        // $scope.otkl_po_tehZH = udel_r1 - udel_jidk;
        // $scope.otkl_pr_tehZH = ($scope.otkl_po_tehZH / udel_r1) * 100;


        $scope.balansChart.xAxis[0].update({
          categories: $scope.labels
        });
        $scope.balansChart.series[0].update({
            name: "Добыча по весам",
            data: r1
        });
        $scope.balansChart.series[1].update({
            name: "Добыча по Ансаган",
            data: r2
        });
        $scope.balansChart.series[2].update({
            name: "Уд. баланс жидкости",
            data: udel_1
        });

        $scope.balansChart.yAxis[1].update({
            title: {
                text: 'Уд. баланс жидкости',
                style: {
                    color: Highcharts.getOptions().colors[2],
                    fontSize: '0.8vw'
                }
            },
            labels: {
                format: '{value} %',
                style: {
                    color: Highcharts.getOptions().colors[2]
                }
            },
        });
        $scope.balansChart.yAxis[0].update({
            title: {
                text: 'Жидкость, м³',
                style: {
                  fontSize: '0.9vw'
                }
            }
        });

        $scope.hour.xAxis[0].update({
            categories: $scope.labels_matrix
        });
        $scope.hour.series[0].update({
            name: "Добыча по весам",
            data: r1
        });
        $scope.hour.series[1].update({
            name: "Добыча по скважинам",
            data: r3
        });
        $scope.hour.series[2].update({
            name: "Тех. режим скважин",
            data: r4
        });

        // $scope.otkl2hour1 = $scope.data_matrix[0][11] - $scope.data_matrix[2][11];
        // $scope.otkl2hour1prc = $scope.otkl2hour1 / $scope.data_matrix[2][11] * 100;
        // $scope.otkl2hour2 = $scope.data_matrix[0][11];
        // $scope.otkl2hour3 = $scope.data_matrix[0][11] - $scope.data_matrix[1][11];
        // $scope.otkl2hour3prc = $scope.otkl2hour3 / $scope.data_matrix[1][11] * 100;

        $scope.updateDataHour = function() {
            $scope.selectedButton_hour = 1;
            $scope.hour.series[0].update({
                name: 'Дебит жидк. за пред. сутки'
            });
            $scope.hour.series[1].update({
                name: 'Фактический дебит жидк.'
            });
            $scope.hour.series[2].update({
                visible: true,
                showInLegend: true,
                name: 'Дебит жидк. по Плану'
            });
            $scope.hour.yAxis[0].update({
                title: {
                    text: 'Добыча жидкости, м³',
                    style: {
                        color: Highcharts.getOptions().colors[1],
                        fontSize: '0.8vw'
                    }
                }
            });
            run_matrix();
        };
        $scope.updateDataHour2 = function() {
            $scope.selectedButton_hour = 2;
            $scope.hour.series[0].update({
                name: 'Дебит нефти за пред. сутки'
            });
            $scope.hour.series[1].update({
                name: 'Фактический дебит нефти'
            });
            $scope.hour.series[2].update({
                visible: true,
                showInLegend: true,
                name: 'Дебит нефти по Плану'
            });
            $scope.hour.yAxis[0].update({
                title: {
                    text: 'Добыча нефти, тн.',
                    style: {
                        color: Highcharts.getOptions().colors[1],
                        fontSize: '0.8vw'
                    }
                }
            });
            run_matrix();
        };
        $scope.updateDataHour3 = function() {
            $scope.selectedButton_hour = 3;
            $scope.hour.series[0].update({
                name: 'Сдача нефти за пред. сутки'
            });
            $scope.hour.series[1].update({
                name: 'Фактическая сдача нефти'
            });
            $scope.hour.series[2].update({
                visible: false,
                showInLegend: false,
                name: 'Сдача нефти по Плану'
            });
            $scope.hour.yAxis[0].update({
                title: {
                    text: 'Сдача нефти, тн.',
                    style: {
                        color: Highcharts.getOptions().colors[1],
                        fontSize: '0.8vw'
                    }
                }
            });
            run_matrix();
        };
    }

    $scope.updateMonth = function(month) {
        $scope.month_txt = month;
        $scope.month = parseInt(month);
        var promise = DataService.getTotalBalance($scope.month + 1);
        promise.then(function(data) {
            balance_data = data;
            run();
        });
    }
    
    $scope.selectedButton_hour = 1;
    var run_matrix = function() {
      $scope.getData_matrix =function() {
          result = [];
          temp = [];
          ind = 0;

          for (j in $scope.matrix_data) {
              ind++;
              var tmp = []
              // tmp.push($scope.matrix_data[j].well.field.name)
              tmp.push($scope.matrix_data[j].well.name)
              tmp.push($scope.matrix_data[j].fluid)
              tmp.push($scope.matrix_data[j].teh_rej_fluid)
              tmp.push($scope.matrix_data[j].teh_rej_oil)
              tmp.push($scope.matrix_data[j].teh_rej_water)
              tmp.push($scope.matrix_data[j].gas)
              temp.push(tmp);
          }

          if (!$scope.allMatrixOtkl1 && !$scope.allMatrixOtkl2 && !$scope.allMatrixOtkl2) {
              temp.sort(function(a,b) {
                  return b[3]-a[3]
              });
          }

          if ($scope.allMatrixOtkl1) {
              temp.sort(function(a,b) {
                  return Math.abs(b[1]-b[2])-Math.abs(a[1]-a[2])
              });
          }

          if (!$scope.allMatrixData1) {
              temp = temp.filter(value => value[5] == 3);
          }


          tempVal = Math.ceil(ind / 6);
          for (var i = 0; i < tempVal; i++) {
              result[i] = [];
          }


          for (var i = 0; i < ind; i++) {
              var j = Math.floor(i / 6);
              result[j].push(temp[i]);
          }
          return result;
      }
      $scope.matrix_data = matrix_data;
      $scope.all_data2 = $scope.getData_matrix();
      $scope.height = screen.height / 87;     
    }
    var run_reverse = function() {
        $scope.rev_date = "";
        $scope.rev_change = function () {
            $scope.rev_data = [];
            $scope.rev_header = ["Дата", "Месторождение", "Тех.жидк", "Тех.нефть", "Обводненность", 
                                 "ρ, т/м3","Простои, ч","Qж, м3/сут","Qн, т/сут","Потери жидкости","Потери нефти"];
            if ($scope.rev_date == "" && $scope.rev_field == 'Общее') {
                for (var dt in reverse_data) {
                    var temp = [];
                    temp.push(dt);
                    temp.push('Общее');
                    var ind = 0;
                    var t_j = 0;
                    var t_o = 0;
                    var obv = 0;
                    var dens = 0;
                    var stops = 0;
                    var d_fluid = 0;
                    var d_oil = 0;
                    var loss_fluid = 0;
                    var loss_oil = 0;

                    for (var field in reverse_data[dt]) {
                        for (var tmp in reverse_data[dt][field]) {
                            ind++;
                            t_j += reverse_data[dt][field][tmp][5];
                            t_o += reverse_data[dt][field][tmp][6];
                            obv += reverse_data[dt][field][tmp][7];
                            dens += reverse_data[dt][field][tmp][8];
                            stops += reverse_data[dt][field][tmp][9];
                            d_fluid += reverse_data[dt][field][tmp][10];
                            d_oil += reverse_data[dt][field][tmp][11];
                            loss_fluid += reverse_data[dt][field][tmp][12];
                            loss_oil += reverse_data[dt][field][tmp][13];
                        }
                    }
                    temp.push(t_j / ind);
                    temp.push(t_o / ind);
                    temp.push(obv / ind);
                    temp.push(dens / ind);
                    temp.push(stops);
                    temp.push(d_fluid);
                    temp.push(d_oil);
                    temp.push(loss_fluid);
                    temp.push(loss_oil);
                    $scope.rev_data.push(temp);
                }
            }
            if ($scope.rev_date != "" && $scope.rev_field == 'Общее') {
                var dt = $scope.rev_date;
                for (var field in reverse_data[dt]) {
                    var temp = [];
                    temp.push(dt);
                    temp.push(field);
                    var ind = 0;
                    var t_j = 0;
                    var t_o = 0;
                    var obv = 0;
                    var dens = 0;
                    var stops = 0;
                    var d_fluid = 0;
                    var d_oil = 0;
                    var loss_fluid = 0;
                    var loss_oil = 0;

                    for (var tmp in reverse_data[dt][field]) {
                        ind++;
                        t_j += reverse_data[dt][field][tmp][5];
                        t_o += reverse_data[dt][field][tmp][6];
                        obv += reverse_data[dt][field][tmp][7];
                        dens += reverse_data[dt][field][tmp][8];
                        stops += reverse_data[dt][field][tmp][9];
                        d_fluid += reverse_data[dt][field][tmp][10];
                        d_oil += reverse_data[dt][field][tmp][11];
                        loss_fluid += reverse_data[dt][field][tmp][12];
                        loss_oil += reverse_data[dt][field][tmp][13];
                    }
                    temp.push(t_j / ind);
                    temp.push(t_o / ind);
                    temp.push(obv / ind);
                    temp.push(dens / ind);
                    temp.push(stops);
                    temp.push(d_fluid);
                    temp.push(d_oil);
                    temp.push(loss_fluid);
                    temp.push(loss_oil);
                    $scope.rev_data.push(temp);
                }
            }
            if ($scope.rev_date == "" && $scope.rev_field != 'Общее') {
                var field = $scope.rev_field;
                for (var dt in reverse_data) {
                    var temp = [];
                    temp.push(dt);
                    temp.push(field);
                    var ind = 0;
                    var t_j = 0;
                    var t_o = 0;
                    var obv = 0;
                    var dens = 0;
                    var stops = 0;
                    var d_fluid = 0;
                    var d_oil = 0;
                    var loss_fluid = 0;
                    var loss_oil = 0;
                    
                    for (var tmp in reverse_data[dt][field]) {
                        ind++;
                        t_j += reverse_data[dt][field][tmp][5];
                        t_o += reverse_data[dt][field][tmp][6];
                        obv += reverse_data[dt][field][tmp][7];
                        dens += reverse_data[dt][field][tmp][8];
                        stops += reverse_data[dt][field][tmp][9];
                        d_fluid += reverse_data[dt][field][tmp][10];
                        d_oil += reverse_data[dt][field][tmp][11];
                        loss_fluid += reverse_data[dt][field][tmp][12];
                        loss_oil += reverse_data[dt][field][tmp][13];
                    }
                    temp.push(t_j / ind);
                    temp.push(t_o / ind);
                    temp.push(obv / ind);
                    temp.push(dens / ind);
                    temp.push(stops);
                    temp.push(d_fluid);
                    temp.push(d_oil);
                    temp.push(loss_fluid);
                    temp.push(loss_oil);
                    $scope.rev_data.push(temp);
                }
            }
            if ($scope.rev_date != "" && $scope.rev_field != 'Общее') {
                $scope.rev_header = ["Дата", "Месторождение", "Скважина", "Время замера", "Замер", "Тех.жидк", "Тех.нефть", "Обводненность", 
                                     "ρ, т/м3","Простои, ч","Qж, м3/сут","Qн, т/сут","Потери жидкости","Потери нефти"];
                var dt = $scope.rev_date;
                var field = $scope.rev_field;
                for (var tmp in reverse_data[dt][field]) {
                    var temp = [];
                    temp.push(dt);
                    temp.push(field);
                    temp.push(reverse_data[dt][field][tmp][2]);
                    temp.push(reverse_data[dt][field][tmp][3]);
                    temp.push(reverse_data[dt][field][tmp][4]);
                    temp.push(reverse_data[dt][field][tmp][5]);
                    temp.push(reverse_data[dt][field][tmp][6]);
                    temp.push(reverse_data[dt][field][tmp][7]);
                    temp.push(reverse_data[dt][field][tmp][8]);
                    temp.push(reverse_data[dt][field][tmp][9]);
                    temp.push(reverse_data[dt][field][tmp][10]);
                    temp.push(reverse_data[dt][field][tmp][11]);
                    temp.push(reverse_data[dt][field][tmp][12]);
                    temp.push(reverse_data[dt][field][tmp][13]);
                    $scope.rev_data.push(temp);
                }
            }
        }
        $scope.rev_reset = function () {
            $scope.rev_date = "";
            $scope.rev_field = 'Общее';
            $scope.rev_change();
        }
        $scope.add_today_data = function () {
            var promise = DataService.add_today_data();
            promise.then(function(data) {
                reverse_data = {};
                var promise = DataService.getReverseCalculation();
                promise.then(function(data) {
                    for (var i in data) {
                        var temp = [];
                        if (!(data[i].timestamp in reverse_data)) {
                            reverse_data[data[i].timestamp] = {};
                        }
                        if (!(data[i].well.field.name in reverse_data[data[i].timestamp])) {
                            reverse_data[data[i].timestamp][data[i].well.field.name] = [];
                        }
                        temp.push(data[i].timestamp);
                        temp.push(data[i].well.field.name);
                        temp.push(data[i].well.name);
                        temp.push(data[i].calc_time);
                        temp.push(data[i].fluid);
                        temp.push(data[i].teh_rej_fluid);
                        temp.push(data[i].teh_rej_oil);
                        temp.push(data[i].teh_rej_water);
                        temp.push(data[i].density);
                        temp.push(data[i].stop_time);
                        var fluid_loss = data[i].fluid / data[i].calc_time * data[i].stop_time;
                        var day_fluid = 24 / data[i].calc_time * data[i].fluid - fluid_loss;
                        var day_oil = day_fluid * (100 - data[i].teh_rej_water) * data[i].density / 100;
                        var oil_loss = fluid_loss * (100 - data[i].teh_rej_water) * data[i].density / 100;
                        temp.push(day_fluid);
                        temp.push(day_oil);
                        temp.push(fluid_loss);
                        temp.push(oil_loss);
                        reverse_data[data[i].timestamp][data[i].well.field.name].push(temp);
                    }
                    run_reverse();
                });
            });
        }

        $scope.rev_change();
    }


    $scope.changeMr = function(field) {
        $scope.wells = [];
        var promise = DataService.getWells(field);
        promise.then(function(data) {
            for (i in data) {
                $scope.wells.push(data[i].name);
            }
            $scope.well = $scope.wells[0];
            var well_data = matrix_data.find(x => x.well.name === $scope.well);
            $scope.fluid_upd = well_data.fluid;
            $scope.teh_rej_water_upd = well_data.teh_rej_water;
            $scope.teh_rej_oil_upd = well_data.teh_rej_oil;
            $scope.teh_rej_fluid_upd = well_data.teh_rej_fluid;
            $scope.gas_upd = well_data.gas;
            
        });
    };
    $scope.changeWell = function(well) {
        var well_data = matrix_data.find(x => x.well.name === well);
        $scope.fluid_upd = well_data.fluid;
        $scope.teh_rej_water_upd = well_data.teh_rej_water;
        $scope.teh_rej_oil_upd = well_data.teh_rej_oil;
        $scope.teh_rej_fluid_upd = well_data.teh_rej_fluid;
        $scope.gas_upd = well_data.gas;
    };

    $scope.changeMainField = function(main_field) {
        $scope.main_field = main_field;
        if (main_field == 'Общее') {
            var promise = DataService.getTotalBalance($scope.month + 1);
            promise.then(function(data) {
                balance_data = data;
                run();
            });
            var promise = DataService.getTotalMatrix();
            promise.then(function(data) {
                matrix_data = data;
                run_matrix();
            });
        } else {
            var promise = DataService.getFieldBalance($scope.month + 1, main_field);
            promise.then(function(data) {
                balance_data = data;
                run();
            });
            var promise = DataService.getFieldMatrix(main_field);
            promise.then(function(data) {
                matrix_data = data;
                run_matrix();
            });
        }
    };


    $scope.update_skv_details = function(fluid, teh_rej_water, teh_rej_oil, teh_rej_fluid, gas) {
        if ($scope.field != 'Общее') {
            var promise = DataService.update_skv_details($scope.well, fluid, teh_rej_water, teh_rej_oil, teh_rej_fluid, gas);
            promise.then(function(data) {
                if (data.status == 200) {
                    $scope.showPopup();
                    $scope.clear_skv_details();
                    var promise = DataService.getTotalMatrix();
                    promise.then(function(data) {
                        matrix_data = data;
                        run_matrix();
                    }); 
                } else {
                    $scope.showPopup2();
                }
                
            });
        }
    };
    $scope.clear_skv_details = function() {
        $scope.fluid_upd = "";
        $scope.teh_rej_water_upd = "";
        $scope.teh_rej_oil_upd = "";
        $scope.teh_rej_fluid_upd = "";
        $scope.gas_upd = "";
        $scope.field = 'Общее';
        $scope.well = 'Выбрать скважину';
        $scope.wells = ['Выбрать скважину'];
    };

    $scope.update_field_details = function(fluid, oilbrutto, oilnetto, density) {
        if ($scope.field_second != 'Общее') {
            var promise = DataService.update_field_details($scope.field_second, fluid, oilbrutto, oilnetto, density);
            promise.then(function(data) {
                if (data.status == 200) {
                    $scope.showPopup();
                    $scope.clear_field_details();
                    var promise = DataService.getTotalBalance($scope.month + 1);
                    promise.then(function(data) {
                        balance_data = data;
                        run();
                    });
                } else {
                    $scope.showPopup2();
                }
                
            });
        }
    };
    $scope.clear_field_details = function() {
        $scope.field_fluid_upd = "";
        $scope.field_oilbrutto_upd = "";
        $scope.field_oilnetto_upd = "";
        $scope.field_density_upd = "";
        $scope.field_second = 'Общее';
    };


    $scope.change_first_operator = function(operator) {
        $scope.operator_first = operator;
    };
    $scope.change_second_operator = function(operator) {
        $scope.operator_second = operator;
    };

    $scope.changeBalanceJidkost = function() {
        run();
    }

    $scope.showReport = function() {
        $ionicModal.fromTemplateUrl("templates/reportMMG.html", {
          scope: $scope
        }).then(function(modal) {
          $scope.modal = modal;
          $scope.modal.show();
        });
    }

    $scope.changeData1 = function(allMatrixData1) {
        $scope.allMatrixData1 = allMatrixData1;
        $scope.all_data2 = $scope.getData_matrix2($scope.ngdu, $scope.cdng, $scope.mr);
    }
    $scope.changeOtkl1 = function(allMatrixOtkl1) {
        $scope.allMatrixOtkl1 = allMatrixOtkl1;
        $scope.all_data2 = $scope.getData_matrix2($scope.ngdu, $scope.cdng, $scope.mr);
    }


    $scope.showPopup = function() {
        var alertPopup = $ionicPopup.alert({
          title: 'Обновление',
          template: 'Данные обновлены!'
        });
    };

    $scope.showPopup2 = function() {
        var alertPopup = $ionicPopup.alert({
          title: 'Обновление',
          template: 'Нет подключения к базе данных!'
        });
    };
  });

